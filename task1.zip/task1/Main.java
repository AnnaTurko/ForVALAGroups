package task1;

import task1.database.Database;
import task1.database.FileDatabase;
import task1.service.PrimeFactors;
import task1.view.SimpleViewer;
import task1.view.Viewer;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    // Path to file for database in you system
    // file and directory must have appropriate rights for read and write
    private final static String fileName = "/Users/anuta/Downloads/send/task1/data/data.txt";

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        Viewer viewer = new SimpleViewer();
        Database database = new FileDatabase(fileName);
        PrimeFactors primeFactors = new PrimeFactors(viewer, database);

        // read data from user
        Scanner scanner = new Scanner(System.in);
        System.out.print("Give me the number:");
        int number = scanner.nextInt();

        // process and show result
        primeFactors.showPrimeFactors(number);
    }
}