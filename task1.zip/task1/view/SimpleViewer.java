package task1.view;

import java.util.Set;

public class SimpleViewer implements Viewer {

    @Override
    public void show(Set<Integer> uniqPrimeFactors, Long duration) {
        if (uniqPrimeFactors != null) {
            uniqPrimeFactors.forEach(prime -> System.out.printf("Prime factor found: %d%n", prime));
        }

        System.out.printf("It took %d milliseconds(s) to find those", duration);
    }
}
