package task1.view;

import java.util.Set;

public interface Viewer {
    void show(Set<Integer> uniqPrimeFactors, Long duration);
}
