package task1.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.Set;

public class FileDatabase implements Database {
    private final String fileName;

    // create file if it doesn't exist
    public FileDatabase(String fileName) throws IOException {
        this.fileName = fileName;
        File file = new File(fileName);
        if (!file.exists()) {
            file.createNewFile();
        }
    }

    @Override
    // try to read serialized data from file
    // deserialized it, and check for existing out number
    public Set<Integer> read(int number) throws IOException, ClassNotFoundException {
        Map<Integer, Set<Integer>> data = null;
        FileInputStream fileIn = new FileInputStream(fileName);
        if (fileIn.available() > 0) {
            ObjectInputStream in = new ObjectInputStream(fileIn);
            data = (Map<Integer, Set<Integer>>) in.readObject();
            in.close();
        }
        fileIn.close();

        Set<Integer> integers = (data != null && data.size() > 0) ? data.get(number) : null;

        return integers;
    }

    @Override
    // Try to serialize and save data to file
    public void write(int number, Set<Integer> primeFactors) throws IOException {
        FileOutputStream fileOut = new FileOutputStream(fileName);
        ObjectOutputStream out = new ObjectOutputStream(fileOut);
        out.writeObject(Map.of(number, primeFactors));
        out.close();
        fileOut.close();
    }
}
