package task1.database;

import java.io.IOException;
import java.util.Set;

public interface Database {

    Set<Integer> read(int number) throws IOException, ClassNotFoundException;

    void write(int number, Set<Integer> primes) throws IOException;
}
