package task1.service;

import task1.database.Database;
import task1.view.Viewer;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class PrimeFactors {
    private final Viewer viewer;
    private final Database database;

    public PrimeFactors(Viewer viewer, Database database) {
        this.viewer = viewer;
        this.database = database;
    }

    public void showPrimeFactors(Integer number) throws IOException, ClassNotFoundException {
        // get start point of time
        Long startTime = System.currentTimeMillis();
        // trying to read from database
        Set<Integer> primeFactors = database.read(number);

        // in case it's in database
        if (primeFactors == null) {
            // get prime factors
            primeFactors = this.getPrimeFactors(number);
            // save result to database
            database.write(number, primeFactors);
        }

        // get end point of time
        Long endTime = System.currentTimeMillis();
        // show resul and calculation execution time
        viewer.show(primeFactors, endTime - startTime);
    }

    public Set<Integer> getPrimeFactors(Integer number) {
        if (number <= 1) {
            throw new IllegalArgumentException("Number must be greater than 1 ");
        }

        // we use set to avoid checking for double of primes
        Set<Integer> primeFactors = new HashSet<>();
        int i = 2;

        // out factor should be not greater than rest number
        // after deleted it by other factors
        while (number >= i) {
            // if it's prime factor, that we add it
            // it stores in single instance, in spite of how many time we add it.
            if (number % i == 0) {
                number = number / i;
                primeFactors.add(i);
            } else {
                // if current checking is 2 than next prime will be 3
                if (i == 2) {
                    i++;
                } else {
                    // after 2 all primes will be odd only
                    // that's why adding by 2
                    i+=2;
                }
            }
        }

        return primeFactors;
    }
}
